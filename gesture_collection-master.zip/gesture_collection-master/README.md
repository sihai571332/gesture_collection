# Running the Gesture Collection Flutter App

1) Navigate to the directory where you want to use for your development

2) Run git clone https://github.com/tmedeiros/gesture_collection.git to clone the repository

3) Run flutter doctor to make sure you have everything you need to run the app

4) Run flutter pub get

5) Run flutter run

6) Use the credential to connect to and administer Firebase:
    Mail Id: gesturedatacollection@gmail.com 
    Password: WearablesData
