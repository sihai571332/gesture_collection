import 'package:flutter/material.dart';

class Gesture {
  String userId;
  String label;
  String xData;
  String yData;
  String zData;
  int dateAdded;

  Gesture(this.userId, this.label, this.xData, this.yData, this.zData,
      this.dateAdded);
}
