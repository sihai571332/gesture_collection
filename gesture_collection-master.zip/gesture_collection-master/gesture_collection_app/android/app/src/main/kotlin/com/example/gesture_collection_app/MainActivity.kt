package com.example.gesture_collection_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
